import pandas as pd
import joblib
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

ROOT = Path(__file__).parent
data = pd.read_csv(ROOT / "data" / "traffic_data.csv")

features = ["hour", "day_of_week", "month", "is_weekend", "weather"]
X = data[features]
y = data["traffic_volume"]

preprocess = ColumnTransformer(
    transformers=[("weather", OneHotEncoder(handle_unknown="ignore"), ["weather"])],
    remainder="passthrough"
)

pipeline = Pipeline([
    ("preprocess", preprocess),
    ("model", RandomForestRegressor(n_estimators=180, random_state=42, min_samples_leaf=2, n_jobs=-1))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
pipeline.fit(X_train, y_train)
predictions = pipeline.predict(X_test)

mae = mean_absolute_error(y_test, predictions)
rmse = np.sqrt(mean_squared_error(y_test, predictions))
r2 = r2_score(y_test, predictions)

(ROOT / "models").mkdir(exist_ok=True)
joblib.dump(pipeline, ROOT / "models" / "traffic_model.joblib")

print("Model trained and saved to models/traffic_model.joblib")
print(f"MAE:  {mae:.2f} vehicles/hour")
print(f"RMSE: {rmse:.2f} vehicles/hour")
print(f"R²:   {r2:.3f}")
