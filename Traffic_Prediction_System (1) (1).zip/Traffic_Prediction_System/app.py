import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

st.set_page_config(page_title="Traffic Flow Predictor", page_icon="🚦", layout="wide")
ROOT = Path(__file__).parent
MODEL_PATH = ROOT / "models" / "traffic_model.joblib"
DATA_PATH = ROOT / "data" / "traffic_data.csv"

st.title("🚦 Traffic Flow Prediction System")
st.caption("A beginner-friendly machine learning project using Random Forest and Streamlit.")
st.info("This starter project uses an illustrative, synthetically generated dataset. Predictions are for learning/demo purposes, not live traffic guidance.")

@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    return joblib.load(MODEL_PATH)

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

model = load_model()
data = load_data()

if model is None:
    st.warning("Model file not found. Run `python train_model.py` in the project folder, then refresh this page.")
    st.stop()

st.sidebar.header("Prediction inputs")
hour = st.sidebar.slider("Hour of day", 0, 23, 8)
day = st.sidebar.selectbox("Day of week", list(range(7)), format_func=lambda x: ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][x])
month = st.sidebar.slider("Month", 1, 12, 6)
weather = st.sidebar.selectbox("Weather", ["Clear", "Cloudy", "Rain", "Fog"])

input_df = pd.DataFrame([{
    "hour": hour,
    "day_of_week": day,
    "month": month,
    "is_weekend": int(day >= 5),
    "weather": weather
}])
prediction = max(0, float(model.predict(input_df)[0]))

c1, c2, c3 = st.columns(3)
c1.metric("Predicted vehicles per hour", f"{prediction:,.0f}")
c2.metric("Selected day", ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"][day])
c3.metric("Weather", weather)

if prediction < 350:
    level, message = "Low", "Traffic is expected to be relatively light."
elif prediction < 750:
    level, message = "Moderate", "Allow some extra travel time."
else:
    level, message = "High", "This time may be busier than usual."
st.subheader(f"Estimated traffic level: {level}")
st.write(message)

st.divider()
left, right = st.columns(2)
with left:
    st.subheader("Traffic volume by hour")
    hourly = data.groupby("hour", as_index=False)["traffic_volume"].mean()
    st.line_chart(hourly.set_index("hour"))
with right:
    st.subheader("Average traffic by weather")
    weather_avg = data.groupby("weather")["traffic_volume"].mean().sort_values(ascending=False)
    st.bar_chart(weather_avg)

st.subheader("Sample dataset")
st.dataframe(data.head(15), use_container_width=True)
st.caption("Day of week: Monday = 0, Sunday = 6. The model estimates hourly traffic volume from the selected conditions.")
