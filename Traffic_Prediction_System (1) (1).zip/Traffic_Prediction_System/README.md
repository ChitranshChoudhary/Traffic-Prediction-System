# Traffic Flow Prediction System

A beginner-friendly machine learning project that predicts estimated hourly traffic volume from:
- Hour of day
- Day of week
- Month
- Weekend indicator
- Weather condition

## Important dataset note
`data/traffic_data.csv` is a **synthetic teaching dataset** generated for this project. It is not real sensor or city traffic data. The app is a learning/demo prototype and must not be used for real-world route or safety decisions.

## Project structure

```text
Traffic_Prediction_System/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── data/
│   └── traffic_data.csv
└── models/
    └── traffic_model.joblib   # created after training
```

## Run on Windows

1. Install Python 3.10 or newer.
2. Open Command Prompt or VS Code terminal in this folder.
3. Create and activate a virtual environment (recommended):

```bash
python -m venv .venv
.venv\Scripts\activate
```

4. Install libraries:

```bash
pip install -r requirements.txt
```

5. Train the model:

```bash
python train_model.py
```

6. Start the Streamlit app:

```bash
streamlit run app.py
```

## Model details
- Algorithm: Random Forest Regressor
- Categorical preprocessing: One-Hot Encoding for weather
- Evaluation: MAE, RMSE, and R-squared
- The training script saves the trained pipeline to `models/traffic_model.joblib`.

## Ideas to improve the project
- Replace the sample data with genuine traffic sensor or city open-data records.
- Add location/road-segment features and timestamp-based lag features.
- Compare Random Forest with Linear Regression, Decision Tree, and Gradient Boosting.
- Add a map only after obtaining reliable geographic traffic data.
- Use a time-based train/test split for a more realistic forecasting evaluation.
